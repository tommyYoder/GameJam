Monster Chess README

Thank you for downloading our development build for our monster chess game, name still being worked on.

This version plays like traditional chess whose explanation can be found in the How to Play Window accessed by 
clicking on the How to Play button. A difference to note is that there is no check or checkmate system so keep
an eye on your king.

The controls of the game are simple:

Left Mouse Button:
Select piece
Select tile to move to
Click on interface items

Right Mouse Button:
Click and hold will let you rotate the camera as you drag the mouse around.

Middle Mouse Button:
Resets Camera to starting rotation depending on whose turn it is.

Last note:

This game does not offer a computer AI to face and is intended to be played with two people
The board will auto rotate to switch between sides. This auto rotate can be disabled by unchecking the Auto
Rotate Box on the HUD

Thanks for your time and I hope you enjoy!